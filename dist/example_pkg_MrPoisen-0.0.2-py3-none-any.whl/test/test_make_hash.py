#def test_hash():
    #assert
